//============================================================================
// Name        : i160033.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
int median(int array[],int size)
{
	int temp;
	for (int j=0;j<size;j++)
	{
		for (int i=0;i<size;i++)
		{
			if (array[i+1]<array[i])
			{
				temp=array[i];
				array[i]=array[i+1];
				array[i+1]=temp;
			}
		}
	}
	return array[size/2];
}


int main() {
	int array[5]={5,3,2,8,7};
	cout<<median(array,5);
}


