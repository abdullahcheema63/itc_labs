#include <iostream>
using namespace std;

void scalarProduct(float array[],int size,int multiplier)
{
	for (int i=0;i<size;i++)
	{
		array[i]=array[i]*multiplier;
	}
}

int main()
{
	float array[5]={1,1,1,1,1};
	scalarProduct(array,5,5);
	for (int i=0;i<5;i++)
	{
		cout<<array[i]<<endl;
	}
	return 0;
}
