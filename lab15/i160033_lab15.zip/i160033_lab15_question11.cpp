#include <iostream>
using namespace std;


int main()
{
	
	int array[5];
	for (int i=0;i<5;i++)
	{
		cout<<"please enter the value for "<<i<<" indesx of array : ";
		cin>>*(array+i);
	}
	cout<<"\n\n";
	for (int i=4;i>=0;i--)
	{
		cout<<*(array+i)<<endl;
	}
	
	
	
	return 0;
}
