#include <iostream>
using namespace std;

int main()
{
	float*pointer1 ,*pointer2 , *pointer3;
	float variable1 ,variable2, variable3;
	pointer1=&variable1;
	pointer2=&variable2;
	pointer3=&variable3;
	*pointer1=10;
	*pointer2=2;
	*pointer3=5;
	cout<<variable1+variable2+variable3;
	
	
	return 0;
}
