#include <iostream>
using namespace std;
void cube(int*);
int main()
{
	int num=2;
	cube(&num);
	cout<<num;
	
	
	return 0;
}

void cube(int *i)
{
	int j=*i;
	for (int k=0;k<2;k++)
	{
		*i=*i*j;
	}
	
}
