#include<iostream>
using namespace std;
int main ()
{
	int array[5];
	for (int i=0;i<5;i++)
	{
		cout<<"enter value for "<<i<<" index of array : ";
		cin>>array[i];
	}
	cout<<"\n\n\n";
	for (int i=0;i<5;i+=2)
	{
		cout<<*(array+i)<<endl;
	}
	
	return 0;
}
