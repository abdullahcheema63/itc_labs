//============================================================================
// Name        : i160033.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
int power(int,int);
int main() {
	cout<<power(2,5);
	return 0;
}
int power(int a,int b)
{
	int c=a;
	for (int i=0;i<b-1;i++)
	{

		c*=a;
	}
	return c;
}

