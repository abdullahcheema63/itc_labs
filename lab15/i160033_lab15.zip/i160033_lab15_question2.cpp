//============================================================================
// Name        : i160033.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
int number_counter(int);
int main() {
	cout<<number_counter(65535);
	return 0;
}
int number_counter(int n)
{
	int count=1;
	for (int i=n;i>10;count++)
	{
		i=i/10;

	}
	return count;
}

