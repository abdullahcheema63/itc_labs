//============================================================================
// Name        : i160033.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
int binaryOneCounter(int);
int main() {
	cout<<binaryOneCounter(65535);
	return 0;
}
int binaryOneCounter(int n)
{
	int count=0;
	while(n>=1)
	{

		if (n%2==1)
		{
			count++;
		}
		n=n/2;

	}
	return count;
}

