#include <iostream>
using namespace std;

int main()
{
	int variable;
	int *pointer;
	pointer=&variable;
	*pointer=10;
	cout<<variable<<endl;
	
	
	return 0;
}
