#include <iostream>
using namespace std;

int ProdeuctOfSum(int array1[],int array2[],int n)
{
	int ans=1;
	for (int i=0;i<n;i++)
	{
		ans*=array1[i]+array2[i];
	}
	return ans;
}
int main ()
{
	int array1[5]={1,2,3,4,5};
	int array2[5]={6,7,8,9,10};
	cout<<ProdeuctOfSum(array1,array2,3);
	return 0;
}
