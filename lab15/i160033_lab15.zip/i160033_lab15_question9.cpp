#include <iostream>
using namespace std;

int main()
{
	int x=10;
	float y=25.25;
	int *px; px=&x;
	float *py; py=&y;
	cout<<"the value of x is "<<*px<<endl;
	cout<<"the address of x is "<<px<<endl;
	cout<<"the value of y is "<<*py<<endl;
	cout<<"the address of y is "<<py<<endl;
	
	
	return 0;
}
