#include <iostream>
using namespace std;
void multiply(double*,int);

int main()
{
	doubled array[5]={2,2,2,2,2};
	multiply(array,5);
	for (int i=0;i<5;i++)
	{
		cout<<array[i]<<endl;
	}
	return 0;
}
void multiply(double *array,int size)
{
	for (int i=0;i<size;i++)
	{
		*(array+i)=*(array+i)*2;
	}
}
