#include <iostream>
using namespace std;
int main()
{
        float initial=2500;
        int count=0;
        while (count<6)
        {
                cout<<initial<<endl;
                initial+=0.04*initial;
                count++;
        }
        
}
