#include <iostream>
using namespace std;
int main()
{
        float number,count;
        count=0;
        cout<<"please enter number: ";
        cin>>number;
        while ((count*count)<=number)
        {
                
                count+=0.00001;
        }
        cout<<count<<endl;
}
