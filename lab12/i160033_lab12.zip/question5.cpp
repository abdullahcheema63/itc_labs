#include <iostream>
using namespace std;
int main()
{
        int first,second,count,number,temp;
        count=1; first=1; second=2;
        cout<<"please enter a number: ";
        cin>>number;
        while (count<number-2)
        {
             temp=second;
             second+=first;
             first=temp;
             count++;   
        }
        cout<<second<<endl;
        
}
