#include <iostream>
using namespace std;
int main()
{
        float sales,salary;
        while (1==1)
        {
                cout<<"enter sales in rupees(negative values to exit): ";
                cin>>sales;
                salary=2000+(0.09*sales);
                if (sales>=0)
                {
                        cout<<"the salary is: "<<salary<<endl;
                        continue;
                }
                else
                {
                        if (sales<0)
                        {
                                break;
                        }
                }
        }
}
