#include <iostream>
using namespace std;
int main()
{
        int x,y;
        y=1;
        cout<<"please enter a number";
        cin>>x;
        while (y<x)
        {
                cout<<y<<" , ";
                y++;
        }
        while (y>0)
        {
                cout<<y<<" , ";
                y--;
        }
        cout<<endl;
}
