#include <iostream>
using namespace std;
int main()
{
        float laptop_price,savings,month;
        month=0;
        savings=5000;
        laptop_price=30000;
        int int_savings,int_laptop_price;
        while (1==1)
        {
                laptop_price=0.02*laptop_price;
                savings+0.07*savings;
                month+=1;
                int_savings=int(savings);
                int_laptop_price=int(laptop_price);
                if (savings>=int_laptop_price)
                {
                        break;
                }
                
        }
        cout<<month<<endl;
        
   
}
