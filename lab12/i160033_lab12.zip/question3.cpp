#include <iostream>
#include <cmath>
using namespace std;
int main()
{
        float sum1,sum2,count1,count2,number,output;
        sum1=5;
        sum2=-10;
        count1=1;
        count2=1;
        cout<<"please enter a number: ";
        cin>>number;
        number=number/2;
        while (count1<number)
        {
                sum1+=5+(2*count1);
                count1++;
        }
        while (count2<number)
        {
                sum2+=(pow(-1,count2+1)*(10+(5*count2)));
                count2++;
        }
        output=sum1+sum2;
        cout<<output<<endl;
        
}
