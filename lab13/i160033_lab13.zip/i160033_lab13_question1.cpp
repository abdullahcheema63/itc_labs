#include <iostream>
using namespace std;
int main(()
{
	int integer[6]={12,12,12,12,12,12};//declaring array of type integer with each value initialized at 6
	double dob[5]={0.5,0.5,0.5,0.5,0.5};//declaring array of type double with each value initialized at 0.5
	char arr[4]={'a','a','a','a'};//declaring array of type a with each value initialized at a
	return 0;
}
