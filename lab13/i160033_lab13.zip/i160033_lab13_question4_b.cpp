#include <iostream>
using namespace std;
int main()
{
	int integer[6]={12,12,12,12,12,12};//declaring array of type integer with each value initialized at 6
	double dob[5]={0.5,0.5,0.5,0.5,0.5};//declaring array of type double with each value initialized at 0.5
	char arr[4]={'a','a','a','a'};//declaring array of type a with each value initialized at a
	cout<<"integer type array "<<endl;
	for (int i=5;i>=0;i--)
	{
		cout<<"value of integer type array at Location "<<i<<" : "<<integer[i]<<endl;
		
	}
	cout<<"double type array "<<endl;
	for (int i=4;i>=0;i--)
	{
		cout<<"enter value of double type array at Location "<<i<<" : "<<dob[i]<<endl;

	}
	cout<<"character type array "<<endl;
	for (int i=3;i>=0;i--)
	{
		cout<<"enter value of character type array at Location "<<i<<" : "<<arr[i]<<endl;

	}

	return 0;
}
