
#include <iostream>
using namespace std;
int main()
{
	int arr[5][5];//declaring array
	//taking input
	for (int i=0;i<5;i++)
	{
		cout<<"entering values for row "<<i<<endl;
		for (int j=0;j<5;j++)
		{
			cin>>arr[i][j];
		}
		
	}
	//asking user for entering the value to search	
	int search; int i1; int j1;
	cout<<"please enter the element to search"<<endl;
	cin>>search;
	//displaying output and searching 
	cout<<"\nthe matrix is\n"
	for (int i=0;i<5;i++)
	{
		for (int j=0;j<5;j++)
		{
			cout<<arr[i][j]<<" ";
			
		}
		cout<<"\n";
	}
	for (int i=0;i<5;i++)
	{
		for (int j=0;j<5;j++)
		{
			
			if (search==arr[i][j]){i=i1; j=j1; break;}
		}
		cout<<"\n";
	}	
	cout<<"the number is at "<<i1<<"th row and "<<j1<<"th column"<<endl;
	return 0;
}
