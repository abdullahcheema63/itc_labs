#include <iostream>
using namespace std;
int main()
{
	int integer[6]={12,12,12,12,12,12};//declaring array of type integer with each value initialized at 6
	double dob[5]={0.5,0.5,0.5,0.5,0.5};//declaring array of type double with each value initialized at 0.5
	char arr[4]={'a','a','a','a'};//declaring array of type a with each value initialized at a
	cout<<"integer type array "<<endl;
	for (int i=0;i<6;i++)
	{
		cout<<"enter value of integer type array at Location "<<i<<" : ";
		cin>>integer[i];
	}
	cout<<"double type array "<<endl;
	for (int i=0;i<5;i++)
	{
		cout<<"enter value of double type array at Location "<<i<<" : ";
		cin>>dob[i];
	}
	cout<<"character type array "<<endl;
	for (int i=0;i<4;i++)
	{
		cout<<"enter value of character type array at Location "<<i<<" : ";
		cin>>arr[i];
	}

	return 0;
}
