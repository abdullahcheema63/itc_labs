#include <iostream>
using namespace std;
int main()
{
	int arr[5][2]; int value=1;
	//initializing array
	for (int i=0;i<5;i++)
	{
		for (int j=0;j<2;j++)
		{
			arr[i][j]=value;
			value++;
		}
	}
	//displaying array
	for (int i=0;i<2;i++)
	{
		for (int j=0;j<5;j++)
		{
			cout<<arr[j][i]<<" ";
		}
		cout<<"\n";
	}	
	return 0;
}
