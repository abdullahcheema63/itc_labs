#include <iostream>
using namespace std;
int main()
{
	int arr[5];
	int min=9999; int max=0; float sum=0; float average;
	for (int i=0;i<5;i++)
	{
		cout<<"please input for location "<<i<<" : ";
		cin>>arr[i];
		if (arr[i]<min)
		{min=arr[i];}
		if (arr[i]>max)
		{max=arr[i];}
		sum+=arr[i];
	}
	average=sum/5;
	cout<<"the minimum is : "<<min<<endl;
	cout<<"the maximum is : "<<max<<endl;
	cout<<"the average is : "<<average<<endl;
	return 0;
}
