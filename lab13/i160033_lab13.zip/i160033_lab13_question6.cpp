
#include <iostream>
using namespace std;
int main()
{
	int arr[5][5];//declaring array
	//taking input
	for (int i=0;i<5;i++)
	{
		cout<<"entering values for row "<<i<<endl;
		for (int j=0;j<5;j++)
		{
			cin>>arr[i][j];
		}
		
	}	
	//displaying output
	cout<<"\nthe matrix is\n"
	for (int i=0;i<5;i++)
	{
		for (int j=0;j<5;j++)
		{
			cout<<arr[i][j]<<" ";
		}
		cout<<"\n";
	}	
	return 0;
}
