#include <iostream>
using namespace std;
int main()
{
	int td[4][4]={{5,12,60,80},{1,16,24,12},{10,25,32,39},{14,99,78,62}};
	float sum=0; float average=0;
	for (int i=0;i<4;i++)
	{
		sum=0;
		average=0;
		for (int j=0;j<4;j++)
		{
			sum+=td[i][j];
		}
		average=sum/4;
		cout<<"the average of row "<<i+1<<" is "<<average<<endl;
	}
	
	return 0;
}
