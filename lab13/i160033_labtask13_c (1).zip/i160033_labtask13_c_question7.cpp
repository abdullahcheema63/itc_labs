#include <iostream>
using namespace std;
int main()
{
	int td[4][4]={{5,12,60,80},{1,16,24,12},{10,25,32,39},{14,99,78,62}};
	int td2[4][4];
	for (int i=0;i<4;i++)
	{
		for (int j=0;j<4;j++)
		{
			td2[i][j]=td[i][j];
		}

	}
	for (int i=0;i<4;i++)
	{
		for (int j=0;j<4;j++)
		{
			cout<<td2[i][j]<<" ";
		}
		cout<<"\n";
	}
	return 0;
}
