#include <iostream>
using namespace std;
int main()
{
	int td[4][4]={{5,12,60,80},{1,16,24,12},{10,25,32,39},{14,99,78,62}};
	int trace=1;
	for (int i=0;i<4;i++)
	{
		for (int j=0;j<4;j++)
		{
			if (i==j){trace*=td[i][j];}
		}
	}
	cout<<"the trace is "<<trace<<endl;
	return 0;
}
