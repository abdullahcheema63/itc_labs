#include <iostream>
using namespace std;
int main()
{
    int td[4][4]={{5, 12, 60,80},{1,16,24,12},{10,25,32,39},{14,99,78,62}};
    int vector[4]={1,2,3,4};
    int result[4];
    for (int i=0;i<4;i++)
    {
        for (int j=0;j<4;j++)
        {
            result[i]+=td[i][j]*vector[j];
        }
    }
    for (int i=0;i<4;i++)
    {
        cout<<result[i]<<endl;
    }
    return 0;
}