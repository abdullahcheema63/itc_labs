#include <iostream>
using namespace std;
int main()
{
	int l[31]={13,99,6,76,11,83,27,84,28,67,66,22,96,46,63,21,65,48,8,14,84,22,28,11,83,87,11,76,6,83,27};
	float sum=0; float average=0;
	for (int i=0;i<31;i++)
	{
		sum+=l[i];
	}
	average=sum/31;
	cout<<"the average is "<<average<<endl;
	return 0;
}
