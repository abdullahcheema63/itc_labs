#include <iostream>
using namespace std;
int main()
{
	int l[31]={13,99,6,76,11,83,27,84,28,67,66,22,96,46,63,21,65,48,8,14,84,22,28,11,83,87,11,76,6,83,27};
	int min=9999; int max=0;
	for (int i=0;i<31;i++)
	{
		if (l[i]<min)
		{
			min=l[i];
		}
	}
	cout<<"the minimum is "<<min<<endl;
	for (int i=0;i<31;i++)
	{
		if (l[i]>max)
		{
			max=l[i];
		}
	}
	cout<<"the maximum is "<<max<<endl;
	cout<<"\n\nthe range is "<<min<<" to "<<max<<endl;
	return 0;
}
