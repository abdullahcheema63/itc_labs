#include <iostream>
using namespace std;
int main()
{
	char all[]="All ";
	char work[]="work ";
	char andd[]="and ";
	char no[]="no ";
	char play[]="play ";
	char make[]="make ";
	char ahmad[]="Ahmad ";
	char a[]="a ";
	char dull[]="dull ";
	char boy[]="boy\n";
	cout<<all<<work<<andd<<no<<play<<make<<ahmad<<a<<dull<<boy;



}
