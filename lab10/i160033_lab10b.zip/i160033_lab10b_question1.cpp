#include <iostream>
using namespace std;
int main()
{
	float a;
	cout<<"please enter number of gallons\n";
	cin>>a;
	cout<<"number of cubic feets is"<<a*0.133671969;
}