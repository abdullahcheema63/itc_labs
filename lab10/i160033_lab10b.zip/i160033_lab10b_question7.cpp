#include <iostream>
using namespace std;
int main()
{
	int a0=10000;
	int n=12;
	float r=0.08;
	int t;
	cout<<"please enter t: ";
	cin>>t;
	float a;
	a=a0*((1+(r/n))**(n*t));
	cout<<"a is "<<a;



}
