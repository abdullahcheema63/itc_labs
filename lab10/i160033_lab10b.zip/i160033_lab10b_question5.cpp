#include <iostream>
using namespace std;
int main()
{
	int count=0;
	int days=0;
	int currentDay=0;
	int finalDay=0;
	cout<<"please enter current day number: ";
	cin>>currentDay;
	cout<<"\nplease enter the number of days of holiday: ";
	cin>>days;
	finalDay=currentDay;
	while (count<days){
		finalDay+=1;
		if (finalDay==7){
				finalDay=0;			
			}

		count+=1;
	}
	cout<<"you will return on : "<<finalDay<<endl;
	
	return 0;
}
