#include <iostream>
using namespace std;
int main()
{
	int count=0;
	int hours=0;
	int currentTime=0;
	int finalTime=0;
	cout<<"please enter current time: ";
	cin>>currentTime;
	cout<<"\nplease enter the number of hours: ";
	cin>>hours;
	finalTime=currentTime;
	while (count<hours){
		finalTime+=1;
		if (finalTime==24){
				finalTime=0;			
			}

		count+=1;
	}
	cout<<"alarm will ring at: "<<finalTime<<endl;
	
	return 0;
}
