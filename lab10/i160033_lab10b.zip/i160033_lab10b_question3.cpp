#include <iostream>
using namespace std;
int main ()
{
	//british pound=1.487usd
	//french franc=0.172usd
	//german duetschemark=0.584usd
	//japanese yen=0.00955usd
	float usd;
	cout<<"please enter the number of us dollars to convert:  ";
	cin>>usd;
	cout<<"british pounds = "<<usd*0.672494956<<endl;
	cout<<"french france = "<<usd*5.813953488<<endl;
	cout<<"german duetschemark = "<<usd*1.712328767<<endl;
	cout<<"japanese yen = "<<usd*104.712041885<<endl;
	return 0;
}
