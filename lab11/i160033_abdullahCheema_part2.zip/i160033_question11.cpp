#include <iostream>
using namespace std;
int main()
{
	int age;
	cout<<"please enter the age: ";
	cin>>age;
	if (age>=65)
	{
	cout<<"you are seniour citizen"<<endl;
	}
	if (age<65 && age>18)
	{
		cout<<"you are adult"<<endl;
	}
	if (age<18)
	{
		cout<<"you are a child"<<endl;
	}
	return 0;

}
