#include <iostream>
using namespace std;
int main()
{
	int n,count;
	count=0;
	cout<<"please enter n ";
	cin>>n;
	while (count<=n)
	{
		cout<<count<<endl;
		count++;
	}
	return 0;
}
