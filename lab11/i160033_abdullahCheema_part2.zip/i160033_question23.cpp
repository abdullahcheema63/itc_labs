#include <iostream>
using namespace std;
int main()
{
	int base,exponent,count,result;
	count=1;
	result=1;
	cout<<"please enter base: ";
	cin>>base;
	cout<<"please enter exponent: ";
	cin>>exponent;
	while (count<=exponent)
	{
		result=result*base;
		count++;
	}
	cout<<result<<endl;
}
