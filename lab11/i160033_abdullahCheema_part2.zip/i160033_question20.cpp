#include <iostream>
using namespace std;
int main()
{
	int number,count;
	count=0;
	cout<<"please enter number: ";
	cin>>number;
	while (count<=10)
	{
		cout<<number<<"*"<<count<<"="<<count*number<<endl;
		count++;
	}


}
