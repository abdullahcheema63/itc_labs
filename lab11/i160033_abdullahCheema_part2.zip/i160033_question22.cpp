#include <iostream>
using namespace std;
int main()
{
	int number,count,factorial;
	cout<<"please enter a number: ";
	cin>>number;
	count=number;
	factorial=1;
	while (count>0)
	{
		factorial=factorial*count;
		count--;
	}
	cout<<factorial<<endl;
	return 0;
	
}
