#include <iostream>
#include <math.h>
using namespace std;
int main()
{
	float a,b,c,underroot_factor,descriminant,numerator1,numerator2;
	cout<<"please enter A: ";
	cin>>a;
	cout<<"please enter b: ";
	cin>>b;
	cout<<"please enter c: ";
	cin>>c;
	underroot_factor=(pow(b,2)-(4*a*c));
	if (underroot_factor<0)
	{
		cout<<"not possible"<<endl;
		return 0;
	}
	descriminant=pow(underroot_factor,0.5);
	numerator1=-b+descriminant;
	numerator2=-b-descriminant;
	cout<<"root one is "<<numerator1/(2*a)<<endl;
	cout<<"root two is "<<numerator2/(2*a)<<endl;
	return 0;


}
