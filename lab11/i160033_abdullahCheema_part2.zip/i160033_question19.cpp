#include <iostream>
using namespace std;
int main()
{
	int count,number;
	count=0;
	cout<<"please enter number: ";
	cin>>number;
	while (count<=number)
	{
		if (count%2!=0)
		{
			cout<<count<<endl;
		}
		count++;
	}


}
