#include <iostream>
using namespace std;
int main()
{
	float num1,num2;
	char operation;
	cout<<"please enter first number: ";
	cin>>num1;
	cout<<"please enter second number: ";
	cin>>num2;
	cout<<"please tell operation from +-*/: ";
	cin>>operation;
	if (operation=='+')
	{
		cout<<"the sum is "<<num1+num2<<endl;

	}
	if (operation=='-')
	{
		cout<<"the difference is "<<num1-num2<<endl;
	}
	if (operation=='*')
	{
		cout<<"the product is "<<num1*num2<<endl;
	}
	if (operation=='/')
	{
		cout<<"the quotient is "<<num1/num2<<endl;
	}
	return 0;
}
