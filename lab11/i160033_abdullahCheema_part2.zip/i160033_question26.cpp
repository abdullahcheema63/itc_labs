#include <iostream>
using namespace std;
int main()
{
	float number_of_inputs,input_number,count,sum;
	count=0;
	sum=0;
	cout<<"please enter number of inputs: ";
	cin>>number_of_inputs;
	while (count<number_of_inputs)
	{
		cout<<"please enter a number: ";
		cin>>input_number;
		sum+=input_number;
		count++;
	}
	cout<<sum/number_of_inputs<<endl;
}
