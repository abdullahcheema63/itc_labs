#include <iostream>
using namespace std;
int main()
{
	int series_one=1;
	int series_two=0;
	int series_three=3;
	int count=0;
	while (count<=100)
	{
		cout<<series_one<<" , "<<series_two<<" , "<<series_three;
		series_one+=2;
		series_two+=2;
		series_three+=3;
		count+=1;
	}
}
