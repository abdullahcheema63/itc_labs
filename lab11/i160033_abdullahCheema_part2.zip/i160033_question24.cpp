#include <iostream>
using namespace std;
int main()
{
	int number_of_inputs,count,min_value,input_number;
	count=1;
	cout<<"please enter number of inputs: ";
	cin>>number_of_inputs;
	cout<<"please enter a number: ";
	cin>>min_value;
	while (count<number_of_inputs)
	{
		cout<<"please enter a number: ";
		cin>>input_number;
		if (input_number<min_value)
		{
			min_value=input_number;
		}
		count++;
	}
	cout<<min_value<<endl;
}
