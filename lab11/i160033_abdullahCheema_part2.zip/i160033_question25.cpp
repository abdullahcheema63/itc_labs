#include <iostream>
using namespace std;
int main()
{
	int number_of_inputs,count,max_value,input_number;
	count=1;
	cout<<"please enter number of inputs: ";
	cin>>number_of_inputs;
	cout<<"please enter a number: ";
	cin>>max_value;
	while (count<number_of_inputs)
	{
		cout<<"please enter a number: ";
		cin>>input_number;
		if (input_number>max_value)
		{
			max_value=input_number;
		}
		count++;
	}
	cout<<max_value<<endl;
}
