#include <iostream>
using namespace std;
int main()
{
	float hours,hourly_salary,final_salary;
	cout<<"please enter hours: ";
	cin>>hours;
	if (hours<0){return 0;}
	cout<<"please enter hourly salary: ";
	cin>>hourly_salary;
	if (hours<=40)
	{
		final_salary=hours*hourly_salary;
	}
	else
	{
		if (hours>40)
		{
			final_salary=(40*hourly_salary)+((hours-40)*(hourly_salary*1.5));
		}
	}
	cout<<"the salary is "<<final_salary<<endl;
	return 0;



}
