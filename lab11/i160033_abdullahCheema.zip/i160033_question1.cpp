#include <iostream>
using namespace std;
int main(){
	int num1, num2;
	cout<<"please enter number 1: ";
	cin>>num1;
	cout<<"please enter number 2: ";
	cin>>num2;
	switch(num1>num2){
		case 1:
			cout<<"the largest number is "<<num1<<endl;
			break;
		case 0:
			cout<<"the largest number is "<<num2<<endl;
			break;
	
	}
	return 0;



}
