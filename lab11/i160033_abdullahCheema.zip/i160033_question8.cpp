#include <iostream>
using namespace std;
int main(){
	int num1,num2,num3;
	cout<<"please enter number 1: ";
	cin>>num1;
	cout<<"please enter number 2: ";
	cin>>num2;
	cout<<"please enter number 3: ";
	cin>>num3;
	if (num1>num2 && num1>num2)//checking number 1 is important
	{
		cout<<num1<<endl;
		if (num2>num3)
		{
			cout<<num2<<endl;
			cout<<num3<<endl;
		}
		else
		{
			cout<<num3<<endl;
			cout<<num2<<endl;
		}
	}
	if (num2>num3 && num2>num3)//checking if number 2 is important
	{
		cout<<num2<<endl;
		if (num1>num3)
		{
			cout<<num1<<endl;
			cout<<num3<<endl;
		}
		else
		{
			cout<<num3<<endl;
			cout<<num1<<endl;
		}
	}
	if (num3>num2 && num3>num1)
	{
		cout<<num3<<endl;
		if (num1>num2)
		{
			cout<<num1<<endl;
			cout<<num2<<endl;
		}
		else
		{
			cout<<num2<<endl;
			cout<<num1<<endl;
		}
	}
	return 0;
}
