#include <iostream>
using namespace std;
int main(){
	int num1,num2,num3;
	cout<<"please enter number 1: ";
	cin>>num1;
	cout<<"please enter number 2: ";
	cin>>num2;
	cout<<"please enter number 3: ";
	cin>>num3;
	if (num1<num2 && num1<num3)//checking number 1 is important
	{
		cout<<"the smallest number is "<<num1<<endl;
	}
	if (num2<num3 && num2<num1)//checking if number 2 is important
	{
		cout<<"the smallest number is "<<num2<<endl;
	}
	if (num3<num2 && num3<num1)
	{
		cout<<"the smallest number is "<<num3<<endl;
	}
	return 0;
}
