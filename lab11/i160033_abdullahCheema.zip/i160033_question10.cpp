#include <iostream>
using namespace std;
int main() {
	float marks;
	cout<<"please enter the number: ";
	cin>>marks;
	char grade;
	if (marks>=90)
	{
		cout<<"the grade is A+"<<endl;
	}
	if (90>marks && marks>=80)
	{
		cout<<"the grade is A"<<endl;
	}
	if (80>marks && marks>=70)
	{
		cout<<"the grade is B+"<<endl;
	}
	if (70>marks && marks>=60)
	{
		cout<<"the grade is B"<<endl;
	}
	if (60>marks && marks>=50)
	{
		cout<<"the grade is C"<<endl;
	}
	if (marks<50)
	{
		cout<<"the grade is F"<<endl;
	}
	
	return 0;

}
